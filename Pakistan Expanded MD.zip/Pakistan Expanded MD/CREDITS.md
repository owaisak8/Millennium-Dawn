# Credits

## Millennium Dawn

This submod builds on **Millennium Dawn: A Modern Day Mod** by the Millennium Dawn
team (https://github.com/MillenniumDawn/Millennium-Dawn), licensed under
Creative Commons Attribution-ShareAlike 4.0 International. As a derivative work,
this submod is released under the same license (see `LICENSE`).

## Restored art

The following images come from the Millennium Dawn repository. They are either
unused files in its `resources/portrait_dump/PAK` folder or files deleted from
the mod in earlier versions and recovered from its git history. All credit for
the artwork goes to the Millennium Dawn contributors who made them.

- **Leader portraits** (`gfx/leaders/PAK/`):
  - Deleted files: Qamar Bajwa, Zubair Hayat, Zahid Mirza, Shahid Mirza, Sher
    Afgun, Umar Faruq Burki, Nazir Ahmed Butt, Mian Mohammad Hussain, Ishfaq
    Ahmad, Sadiq Ali, Zafar Iqbal, Zafar Abbasi, Muhammad Amjad Khan Niazi,
    Khaleem Shaukat, Mukhtar Khan, Sajid Wazir Khan, Shah Masood, Athar Abbas
    (alternate) and Maulana Fazlullah (alternate).
  - Unused files: Hina Rabbani Khar, Mir Hasil Khan Bizenjo, Afrasiab Khattak,
    Saira Afzal Tarar, Ayla Malik, Asifa Bhutto-Zardari, Fatima Bhutto, Sultan
    Amir Tarar, Muhammad Rafiq Tarar, Mamnoon Hussain, Maulvi Nazir, Hasham
    Siddique, and Pervez Musharraf in uniform.
- **Small portraits and minister idea icons** were derived from these portraits
  for this submod.
- **Pakistan ISI faction icon**, deleted in 2024.
- **Focus icons** "Pakistan target" and "Pakistan pressure", from the discarded
  MD4 icon set.
- **Technology icons** for the JF-17 and Al-Khalid, deleted in 2022.

Restoring `Portrait_Zubair_Hayat.dds` also fixes a portrait that Millennium
Dawn's own Pakistani leader script still references.

## Reference material

Pakistan scenario events (removed in 2026) as a reference list of dates.
