version="2.0.1"
name="Millennium Dawn: Pakistan Expanded"
tags={
	"National Focuses"
	"Events"
	"Gameplay"
}
dependencies={
	"Millennium Dawn: A Modern Day Mod"
	"Millennium Dawn: Developer Version"
}
supported_version="1.19.*"
